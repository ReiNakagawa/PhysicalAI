import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist # ロボットの速度指令
from sensor_msgs.msg import LaserScan # LiDARデータ用
# from sensor_msgs.msg import Image # カメラ画像用
# from cv_bridge import CvBridge # OpenCVとROS Imageメッセージの変換用 (カメラ画像を使う場合)
import numpy as np
# import cv2 # OpenCV (カメラ画像を使う場合)

class RobotControllerNode(Node):
    def __init__(self):
        super().__init__('robot_controller_node')
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10) # 速度指令をパブリッシュ
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan', # TurtleBot3 の LiDAR トピック
            self.laser_callback,
            10
        )
        # カメラ画像を使う場合は以下の行を有効にする
        # self.bridge = CvBridge()
        # self.image_subscription = self.create_subscription(
        #     Image,
        #     '/camera/image_raw', # TurtleBot3 のカメラ画像トピック
        #     self.image_callback,
        #     10
        # )
        self.get_logger().info('Robot Controller Node has been started.')

    def laser_callback(self, msg):
        # LiDAR データから障害物回避のロジックを実装
        # msg.ranges に距離データが配列として入っています。
        # 例: 正面方向の距離データ（中央付近の最小値を見る）
        # TurtleBot3 の LiDAR は通常 360 度スキャンで、ranges[0] が正面、rangesのインデックスが増えるにつれて反時計回り

        min_distance = np.inf
        # 前方方向（例として -30度から +30度）の範囲を見る
        # TurtleBot3のLiDARのranges配列のサイズは360であることが多い。
        # 各要素が1度に対応すると仮定して、中央から±30度を見る範囲
        # 配列の中心を0度、右方向を負、左方向を正と仮定 (LiDARの種類による)

        # 簡略化のため、配列の最初と最後の部分（正面方向）を見る
        # ranges[0] は正面、ranges[len/2] は後方の場合が多い
        # rangesの正確なインデックスと角度の対応は、ロボットのURDFやドキュメントで確認

        # ここでは、簡略化のため、配列の先頭と末尾（正面方向）と中央（左右）を考慮
        # rangesの正確なインデックスと角度の対応は、ロボットのURDFやドキュメントで確認
        # 通常、ranges[0]が正面、または中央付近が正面になるように調整されている
        # 例として、配列の最初の10要素と最後の10要素（正面方向）を見る
        front_ranges = np.array(msg.ranges[0:30] + msg.ranges[-30:]) # 前方60度の範囲

        min_distance = np.min(front_ranges[np.isfinite(front_ranges)]) # 無限大（検出なし）を除外

        twist = Twist()
        
        MAX_LINEAR_SPEED = 0.5
        MAX_ANGULAR_SPEED = 1.0
        
        if min_distance < 0.5: # 0.5m以内に障害物がある場合
            self.get_logger().info(f'Obstacle detected! Min distance: {min_distance:.2f} m. Turning...')
            twist.linear.x = 0.0 # 停止
            twist.angular.z = MAX_ANGULAR_SPEED # 右旋回 (またはランダム)
        elif min_distance < 1.0: # 少し近づいたら減速
            twist.linear.x = MAX_LINEAR_SPEED # ゆっくり前進
            twist.angular.z = 0.0
        else: # 障害物がない場合、直進
            twist.linear.x = MAX_LINEAR_SPEED # 前進
            twist.angular.z = 0.0

        self.publisher_.publish(twist) # 指令をパブリッシュ

    # カメラ画像を使う場合の実装例
    # def image_callback(self, msg):
    #     try:
    #         cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
    #     except CvBridgeError as e:
    #         self.get_logger().error(f"CvBridge Error: {e}")
    #         return
    #
    #     # ここに画像処理とAI推論のロジックを記述
    #     # 例: cv2.imshow("Robot Camera", cv_image)
    #     # 例: オブジェクト検出を行い、その結果に基づいてTwistメッセージを生成
    #
    #     # 処理が重い場合、Twistメッセージのパブリッシュを別途タイマーで行うか、
    #     # 別のノードに処理を分けることを検討

def main(args=None):
    rclpy.init(args=args)
    node = RobotControllerNode()
    try:
        rclpy.spin(node) # ノードを常時実行
    except KeyboardInterrupt:
        pass # Ctrl+C で終了
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
